#!/bin/bash
rm -rf /var/www/html/torrent/log/*