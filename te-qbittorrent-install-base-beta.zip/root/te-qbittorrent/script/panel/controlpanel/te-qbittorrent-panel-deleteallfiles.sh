#!/bin/bash
rm -rf /var/www/html/torrent/files/*
mkdir -p /var/www/html/torrent/files/torrents/
mkdir -p /var/www/html/torrent/files/downloads/
mkdir -p /var/www/html/torrent/files/clouds/googledrive/
mkdir -p /var/www/html/torrent/files/clouds/onedrive/
chown -R www-data:www-data /var/www/html/
chmod -R 775 /var/www/html/
