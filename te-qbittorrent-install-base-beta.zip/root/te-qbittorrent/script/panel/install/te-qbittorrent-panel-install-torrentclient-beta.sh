#!/bin/bash
cd /root/te-qbittorrent/script/install/
curl https://whmcs.the-entertainment.com/te-services/torrent-services/te-qbittorrent/release/beta/script/panel/te-qbittorrent-preinstall-torrentclient-beta.sh -o /root/te-qbittorrent/script/install/te-qbittorrent-preinstall-torrentclient-beta.sh -O
chmod +x /root/te-qbittorrent/script/install/te-qbittorrent-preinstall-torrentclient-beta.sh
screen -d -m bash /root/te-qbittorrent/script/install/te-qbittorrent-preinstall-torrentclient-beta.sh