#!/bin/bash
rclone -v --stats 1s --exclude '.*{/**,}' copy /var/www/html/torrent/files/clouds/onedrive/ onedrive:the-entertainment