#!/bin/bash
screen -d -m -S ping ping localhost
screen -S ping -X quit
screen -S onedrive -X quit
screen -d -m -S onedrive bash /root/te-qbittorrent/script/panel/cloudsync/te-qbittorrent-cloudsync-onedrive-upload.sh