#!/bin/bash
screen -d -m -S ping ping localhost
screen -S ping -X quit
screen -S googledrive -X quit
screen -d -m -S googledrive bash /root/te-qbittorrent/script/panel/cloudsync/te-qbittorrent-cloudsync-googledrive-upload.sh