#!/bin/bash
bash /root/te-qbittorrent/script/panel/cloudsync/te-qbittorrent-cloudsync-googledrive-copy.sh 2>&1|tee /var/www/html/torrent/log/te-qbittorrent-cloudsync-googledrive-upload.log