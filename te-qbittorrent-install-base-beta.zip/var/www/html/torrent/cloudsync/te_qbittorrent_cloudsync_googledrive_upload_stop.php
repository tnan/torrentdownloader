<?php
$connection = ssh2_connect('localhost', 22, array('hostkey'=>'ssh-rsa'));
ssh2_auth_pubkey_file($connection, 'root', '/home/ssh/id_rsa.pub', '/home/ssh/id_rsa');
$stream = ssh2_exec($connection, 'screen -S googledrive -X quit');
stream_set_blocking($stream, true);
$stream_out = ssh2_fetch_stream($stream, SSH2_STREAM_STDIO);
echo stream_get_contents($stream_out);
?>
<center>Google Drive Upload Stopped<center>