<center>
<iframe frameBorder="0" width="100%" height="500px" src="te_qbittorrent_cloudsync_onedrive_upload_progress2.php"></iframe>
<iframe frameBorder="0" width="0" height="0" src="te_qbittorrent_cloudsync_onedrive_upload.php"></iframe>
</center>