<?php
$filename = '/var/www/html/torrent/log/te-qbittorrent-cloudsync-onedrive-upload.log';  //about 500MB
$output = shell_exec('exec tail -n 20 ' . $filename);  //only print last 50 lines
echo str_replace(PHP_EOL, '<br />', $output);         //add newlines
?>
